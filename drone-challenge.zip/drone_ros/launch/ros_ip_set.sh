# Configurar este fichero para vuestra tarjeta de red, 
# y que GIT lo ignore.

# PC despacho Rafa
export ROS_IP=$(ifconfig eno1 | grep "Direc. inet" | awk -F: '{print $2}' | awk '{print $1}')

# VM casa Rafa
#export ROS_IP=$(ifconfig enp0s3 | grep "inet addr" | awk -F: '{print $2}' | awk '{print $1}')

